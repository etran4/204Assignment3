/**
 * 
 * @author Ethan Tran
 *
 */
import java.util.Comparator;
import java.util.ListIterator;

public class SortedDoubleLinkedList<T> extends BasicDoubleLinkedList<T> {
	private Comparator<T> comparator;

	/**
	 * 
	 * 
	 * @param comparator
	 */
	public SortedDoubleLinkedList(Comparator<T> comparator) {
		this.comparator = comparator;
	}

	public void add(T data) {
		Node current = head;
		while (current != null) {
			if (comparator.compare(data, current.data) <= 0) {
				if (current == head) {
					super.addToFront(data);
					return;
				}
				Node prev = current.prev;
				Node entry = new Node(data);
				entry.prev = prev;
				entry.next = current;
				current.prev = entry;

				if (prev != null) {
					prev.next = entry;
				}
				return;
			}
			current = current.next;
		}
		super.addToEnd(data);
	}

	/**
	 * 
	 * When the operation is invalid for the sorted list
	 * @throws UnsupportedOperationException
	 */
	@Override
	public void addToEnd(T data) {
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * When the operation is invalid for the sorted list
	 * @throws UnsupportedOperationException
	 */
	@Override
	public void addToFront(T data) {
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * 
	 * @return iterator
	 */
	@Override
	public ListIterator<T> iterator() {
		return super.iterator();
	}

	/**
	 * 
	 * Calls the super class remove method for the remove operation
	 * @param data
	 * @return Node
	 */
	@Override
	public Node remove(T data, Comparator<T> comparator) {
		return super.remove(data, comparator);
	}
}