/**
 * 
 * @author Ethan Tran
 *
 */
import static org.junit.Assert.*;

import java.util.Comparator;
import java.util.ListIterator;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class BasicDoubleLinkedListTest_STUDENT {
	BasicDoubleLinkedList<String> linkedString;
	BasicDoubleLinkedList<Double> linkedDouble;
	StringComparator comparator;
	DoubleComparator comparatorD;
	
	@Before
	public void setUp() throws Exception {
		linkedString = new BasicDoubleLinkedList<String>();
		linkedString.addToEnd("Purple");
		linkedString.addToEnd("White");
		comparator = new StringComparator();
		
		linkedDouble = new BasicDoubleLinkedList<Double>();
		linkedDouble.addToEnd(15.0);
		linkedDouble.addToEnd(100.0);
		comparatorD = new DoubleComparator();
	}

	@After
	public void tearDown() throws Exception {
		linkedString = null;
		linkedDouble = null;
		comparatorD = null;
		comparator = null;
	}

	@Test
	public void testGetSize() {
		assertEquals(2,linkedString.getSize());
		assertEquals(2,linkedDouble.getSize());
	}
	
	@Test
	public void testaddToEnd() {
		assertEquals("White", linkedString.getLast());
		linkedString.addToEnd("Done");
		assertEquals("Done", linkedString.getLast());
	}
	
	@Test
	public void testAddToFront() {
		assertEquals("Purple", linkedString.getFirst());
		linkedString.addToFront("Brown");
		assertEquals("Brown", linkedString.getFirst());
	}
	
	@Test
	public void testGetFirst() {
		assertEquals("Purple", linkedString.getFirst());
		linkedString.addToFront("Narnia");
		assertEquals("Narnia", linkedString.getFirst());
	}

	@Test
	public void testGetLast() {
		assertEquals("White", linkedString.getLast());
		linkedString.addToEnd("Narnia");
		assertEquals("Narnia", linkedString.getLast());
	}
	
	@Test
	public void testIteratorSuccessfulNext() {
		linkedString.addToFront("Brown");
		linkedString.addToEnd("Done");
		ListIterator<String> iterator = linkedString.iterator();
		assertEquals(true, iterator.hasNext());
		assertEquals("Brown", iterator.next());
		assertEquals("Purple", iterator.next());
		assertEquals("White", iterator.next());
		assertEquals(true, iterator.hasNext());
		assertEquals("Done", iterator.next());
	}
	
	@Test
	public void testRetrieveFirstElement() {
		assertEquals("Purple", linkedString.getFirst());
		linkedString.addToFront("Narnia");
		assertEquals("Narnia", linkedString.getFirst());
		assertEquals("Narnia", linkedString.retrieveFirstElement());
		assertEquals("Purple",linkedString.getFirst());
		assertEquals("Purple", linkedString.retrieveFirstElement());
		assertEquals("White",linkedString.getFirst());
		
	}

	@Test
	public void testRetrieveLastElement() {
		assertEquals("White", linkedString.getLast());
		linkedString.addToEnd("Narnia");
		assertEquals("Narnia", linkedString.getLast());
		assertEquals("Narnia", linkedString.retrieveLastElement());
		assertEquals("White",linkedString.getLast());
	}

	private class StringComparator implements Comparator<String>
	{

		@Override
		public int compare(String arg0, String arg1) {
			// TODO Auto-generated method stub
			return arg0.compareTo(arg1);
		}
		
	}
	
	private class DoubleComparator implements Comparator<Double>
	{

		@Override
		public int compare(Double arg0, Double arg1) {
			// TODO Auto-generated method stub
			return arg0.compareTo(arg1);
		}	
	}
}