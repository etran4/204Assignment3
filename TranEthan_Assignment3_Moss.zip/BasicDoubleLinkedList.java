/**
 * 
 * @author Ethan Tran
 *
 */
import java.util.ArrayList;
import java.util.Comparator;
import java.util.ListIterator;
import java.util.NoSuchElementException;

public class BasicDoubleLinkedList<T> implements Iterable<T> {
	protected Node head, tail;
	protected int size;

	public BasicDoubleLinkedList() {
		size = 0;
	}
	
	/**
	 * add data to end of linkedlist
	 * 
	 * @param data
	 * @return current state of linkedlist
	 */
	public void addToEnd(T data) {
		Node entry = new Node(data);
		if (tail == null) {
			head = entry;
			tail = head;
		}
		else
		{
			tail.next = entry;
			entry.prev = tail;
			tail = entry;
		}
		size++;
	}

	/**
	 * add data to front of linkedlist
	 * 
	 * @param data
	 * @return current state of linkedlist
	 */
	public void addToFront(T data) {
		Node entry = new Node(data);
		if (head == null) {
			head = entry;
			tail = head;
		}
		else
		{
			head.prev = entry;
			entry.next = head;
			head = entry;
		}
		size++;
	}

	/**
	 * get head of linkedlist
	 * 
	 * @return head element
	 */
	public T getFirst() {
		if (head == null) {
			return null;
		}
		return head.data;
	}

	/**
	 * get tail of linkedlist
	 * 
	 * @return tail element
	 */
	public T getLast() {
		if (tail == null) {
			return null;
		}
		return tail.data;
	}

	/**
	 * the size of the linked list
	 * 
	 * @return size
	 */
	public int getSize() {
		return size;
	}

	/**
	 * iterator
	 * 
	 * @return modified list iterator object
	 * @throw UnsupportedOperationException
	 * @throw NoSuchElementException
	 */
	@Override
	public ListIterator<T> iterator() throws UnsupportedOperationException, NoSuchElementException {
		return new DoubleLinkedListIterator();
	}

	/**
	 * remove head occurrence of targetData from linkedlist
	 * 
	 * @param targetData
	 * @param comparator
	 * @return current state of linkedlist
	 */
	public Node remove(T targetData, Comparator<T> comparator) {
		Node current = head;

		while (current != null) {
			if (comparator.compare(targetData, current.data) == 0) {
				Node next = current.next;
				Node prev = current.prev;

				if (current == head) {
					head = next;
					next.prev = null;
				} else if (current == tail) {
					tail = prev;
					prev.next = null;
				} else {
					prev.next = next;
					next.prev = prev;
				}
				size--;
				break;
			}
			current = current.next;
		}
		return current;
	}

	/**
	 * removes and returns head element from linkedlist
	 * 
	 * @return data of the head element if exists, otherwise null
	 */
	public T retrieveFirstElement() {
        return head != null ? remove(head.data, new InnerComparator()).data : null;
    }

	/**
	 * removes and returns tail element from linkedlist
	 * 
	 * @return data of tail element if exists, otherwise null
	 */
	public T retrieveLastElement() {
        return tail != null ? remove(tail.data, new InnerComparator()).data : null;
    }

	
	public ArrayList<T> toArrayList() {
		ArrayList<T> array = new ArrayList<T>();
		ListIterator<T> iterator = iterator();

		while (iterator.hasNext()) {
			array.add(iterator.next());
		}

		return array;
	}

	protected class Node {
        protected Node prev, next;
        protected T data;

        public Node(T data) {
            this.data = data;
        }
    }

	/**
	 * double linked iterator
	 */
	protected class DoubleLinkedListIterator implements ListIterator<T> {
		Node index;
		Node prevIndex;

		DoubleLinkedListIterator() {
			index = head;
		}

		/**
		 * check if there is another element in list
		 * 
		 * @return true if not tail element
		 */
		@Override
		public boolean hasNext() {
			return index != null;
		}

		/**
		 * set current pointer to next one if possible
		 * 
		 * @throw NoSuchElementException when not possible to set pointer to next one
		 * @return data of next element
		 */
		@Override
		public T next() throws NoSuchElementException {
			if (hasNext()) {
				T data = index.data;
				prevIndex = index;
				index = index.next;
				return data;
			}

			throw new NoSuchElementException();
		}

		/**
		 * check if there is an element before i in list
		 * 
		 * @return true if not head element
		 */
		@Override
		public boolean hasPrevious() {
            return index!= null ? index.prev != null : prevIndex != null;
		}

		/**
		 * set current pointer to previous one if possible
		 * 
		 * @throw NoSuchElementException when not possible to set pointer to previous
		 *        one
		 * @return data of previous element
		 */
		@Override
        public T previous() throws NoSuchElementException {
            index = prevIndex;

            if (index != null) {
                prevIndex = index.prev;
                return index.data;

            } else {
                throw new NoSuchElementException();
            }
        }

		@Override
		public int nextIndex() throws UnsupportedOperationException {
			throw new UnsupportedOperationException();
		}

		@Override
		public int previousIndex() throws UnsupportedOperationException {
			throw new UnsupportedOperationException();
		}

		@Override
		public void remove() throws UnsupportedOperationException {
			throw new UnsupportedOperationException();
		}

		@Override
		public void set(T e) throws UnsupportedOperationException {
			throw new UnsupportedOperationException();
		}

		@Override
		public void add(T e) throws UnsupportedOperationException {
			throw new UnsupportedOperationException();
		}
	}

	private class InnerComparator implements Comparator<T> {
        public int compare(T arg0, T arg1) {
            return arg0 == arg1 ? 0 : 1;
        }
    }
}